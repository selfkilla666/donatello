
class AuthenticateError(Exception):
    pass

class IncompleteProfileSettings(Exception):
    pass
